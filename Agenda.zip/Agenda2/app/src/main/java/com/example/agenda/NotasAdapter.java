package com.example.agenda;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class NotasAdapter extends RecyclerView.Adapter<NotasAdapter.NotaViewHolder> {

    private List<Nota> listaNotas;
    private OnNotaLongClickListener notaLongClickListener;

    // Constructor para recibir la lista de notas
    public NotasAdapter(List<Nota> listaNotas) {
        this.listaNotas = listaNotas != null ? listaNotas : new ArrayList<>();
    }

    // Método para obtener la lista de notas
    public List<Nota> getListaNotas() {
        return listaNotas;
    }

    public interface OnNotaLongClickListener {
        void onNotaLongClick(int position);
    }

    public void setOnNotaLongClickListener(OnNotaLongClickListener listener) {
        this.notaLongClickListener = listener;
    }

    // Método para actualizar la lista de notas
    public void actualizarLista(List<Nota> nuevaLista) {
        listaNotas.clear();
        listaNotas.addAll(nuevaLista);
        notifyDataSetChanged();
    }

    // Método que crea nuevas instancias de NotaViewHolder (invocado por el layout manager)
    @NonNull
    @Override
    public NotaViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View vistaItem = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_nota, parent, false);
        return new NotaViewHolder(vistaItem);
    }

    // Método que actualiza el contenido de un ViewHolder según su posición en la lista
    @Override
    public void onBindViewHolder(@NonNull NotaViewHolder holder, int position) {
        Nota nota = listaNotas.get(position);
        holder.bindNota(nota);
    }

    // Método que devuelve la cantidad de elementos en la lista
    @Override
    public int getItemCount() {
        return listaNotas.size();
    }

    // Clase interna para representar el ViewHolder
    public class NotaViewHolder extends RecyclerView.ViewHolder {
        private TextView txtTitulo, txtDescripcion, txtFecha;

        public NotaViewHolder(@NonNull View itemView) {
            super(itemView);
            txtTitulo = itemView.findViewById(R.id.txtTitulo);
            txtDescripcion = itemView.findViewById(R.id.txtDescripcion);
            txtFecha = itemView.findViewById(R.id.txtFecha);

            itemView.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
                    if (notaLongClickListener != null) {
                        notaLongClickListener.onNotaLongClick(getAdapterPosition());
                        return true;
                    }
                    return false;
                }
            });
        }

        // Método para enlazar una Nota con la vista del ViewHolder
        public void bindNota(Nota nota) {
            txtTitulo.setText(nota.getTitulo());
            txtDescripcion.setText(nota.getDescripcion());
            txtFecha.setText(nota.getFecha());
        }
    }
}

