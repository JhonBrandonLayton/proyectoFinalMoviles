package com.example.agenda;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import java.util.HashMap;
import java.util.Map;

public class AgregarNota extends AppCompatActivity {

    private EditText edtTitulo, edtDescripcion, edtFecha;
    private Button btnGuardar;

    private FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agregar_nota);

        // Inicializar Firebase
        db = FirebaseFirestore.getInstance();

        // Obtener referencias de los elementos UI
        edtTitulo = findViewById(R.id.edtTitulo);
        edtDescripcion = findViewById(R.id.edtDescripcion);
        edtFecha = findViewById(R.id.edtFecha);
        btnGuardar = findViewById(R.id.btnGuardar);

        // Agregar listener al botón de guardar
        btnGuardar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                guardarNota();
            }
        });
    }

    private void guardarNota() {
        // Obtener valores de los EditText
        String titulo = edtTitulo.getText().toString();
        String descripcion = edtDescripcion.getText().toString();
        String fecha = edtFecha.getText().toString();

        // Validar que los campos no estén vacíos
        if (titulo.isEmpty() || descripcion.isEmpty() || fecha.isEmpty()) {
            // Mostrar mensaje de error si hay campos vacíos
            // Puedes usar un Toast o cualquier otro método para mostrar mensajes al usuario
            Toast.makeText(AgregarNota.this, "Todos los campos son obligatorios", Toast.LENGTH_SHORT).show();
            return;
        }

        // Crear un mapa con los datos de la nota
        Map<String, Object> nota = new HashMap<>();
        nota.put("titulo", titulo);
        nota.put("descripcion", descripcion);
        nota.put("fecha", fecha);

        // Guardar la nota en Firebase
        db.collection("notas")
                .add(nota)
                .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                    @Override
                    public void onSuccess(DocumentReference documentReference) {
                        // La nota se guardó exitosamente
                        Toast.makeText(AgregarNota.this, "Nota agregada con éxito", Toast.LENGTH_SHORT).show();
                        // Puedes agregar lógica adicional aquí, como mostrar un mensaje al usuario
                        finish();
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(AgregarNota.this, "Error al guardar la nota", Toast.LENGTH_SHORT).show();
                        // Loguear el error para propósitos de desarrollo
                        Log.e("AgregarNota", "Error al guardar la nota", e);
                    }
                });
    }
}
