package com.example.agenda;
public class Nota {
    private String titulo;
    private String descripcion;
    private String fecha;

    private String id;

    // Constructor vacío requerido para Firestore
    public Nota() {
        // Asignar valores predeterminados en lugar de dejar las propiedades como nulas
        this.titulo = "";
        this.descripcion = "";
        this.fecha = "";
        this.id = "";
    }


    // Métodos getter y setter
    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
}
